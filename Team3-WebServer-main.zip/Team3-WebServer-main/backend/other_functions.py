import csv
import os
import smtplib
from email.message import EmailMessage
from time import time

job_genomes_folder = 'genomes'
job_metadata_folder = 'metadata'
job_assembly_folder = 'assembled_genomes'
job_gene_pred_folder = 'genes'
job_compGenomics_folder = 'comparative_genomics'

def JOBtoLIST(_SVfile,Delimiter):
    return SVtoLIST(_SVfile,Delimiter)
    if os.path.isfile(_SVfile) == True:
        while True:
            my_log(f'READ_JOBS: the status of {_SVfile} is {file_control(_SVfile, flag="status")}')
            if file_control(_SVfile, flag='status') != 'locked':
                my_log(f'OPEN_JOB_FILE: ')
                file_control(_SVfile, flag='lock')
                with open(_SVfile, 'r') as fo:
                        reader = csv.reader(fo, delimiter=Delimiter)
                        return list(reader)
    else:
        my_log(f'the file {_SVfile} does not seem to exists')

def LISTtoJOB(LIST,Delimiter, _SVfile):
    return LISTto_SV(LIST,Delimiter, _SVfile)
    if os.path.isfile(_SVfile) == True:
        while True:
            my_log(f'WRITE_JOBS: the status of {_SVfile} is {file_control(_SVfile, flag="status")}')
            if file_control(_SVfile, flag='status') == 'locked':
                my_log(f'WRITE_JOBS: updating')

                with open(_SVfile, 'w') as fo:
                    writer = csv.writer(fo, delimiter = Delimiter)
                    writer.writerows(LIST)
                file_control(_SVfile, flag='unlock')
            else:
                my_log(f'WRITE_JOBS: seemes to have missed locking of {_SVfile}') 
    else:
        my_log(f'the file {_SVfile} does not seem to exists')


def SVtoLIST(_SVfile,Delimiter):
    with open(_SVfile, 'r') as fo:
            reader = csv.reader(fo, delimiter=Delimiter)
            return list(reader)

def LISTto_SV(LIST,Delimiter, _SVfile):
    with open(_SVfile, 'w') as fo:
        writer = csv.writer(fo, delimiter = Delimiter)
        writer.writerows(LIST)

def create_jobs_file(jobs_file,task,username):
    LISTto_SV([['1',username,task,'incomplete','email_not_sent']],',',jobs_file)


# possible new sql database 
# with:
#     jobID: SHA1 hash
#     time: time
#     email: 
#     job_type:
#     first_email_sent:
#     final_email_sent
#     job_status:

# add ctrl 
def create_job_id(jobs_file,task,dir_storage,username):
    if os.path.exists(jobs_file):
        print('adding job to jobs file')
        existing_jobs = JOBtoLIST(jobs_file,',')

        if existing_jobs != []:
            # print(existing_jobs)
            new_job_id = int(existing_jobs[-1][0]) + 1
            new_job_id = str(new_job_id)
            existing_jobs.append([new_job_id,username,task,'incomplete','email_not_sent'])
            LISTtoJOB(existing_jobs,',',jobs_file)
            
        else:
            create_jobs_file(jobs_file,task,username)
            new_job_id = 1
    else:
        print(f'jobs files does not exists, created a new one {jobs_file}')
        create_jobs_file(jobs_file,task,username)
        new_job_id = 1


    print(f'job with job id: {new_job_id} of task: {task} added to jobs file: {jobs_file}')
    job_folder = os.path.join(dir_storage,str(new_job_id))
    os.mkdir(job_folder)
    os.mkdir(os.path.join(job_folder, job_genomes_folder))
    os.mkdir(os.path.join(job_folder, job_metadata_folder))
        
    # os.mkdir(os.path.join(job_folder, job_assembly_folder))
    # os.mkdir(os.path.join(job_folder, job_gene_pred_folder))
    os.mkdir(os.path.join(job_folder, job_compGenomics_folder))
    return new_job_id


def job_folder(job_id,sub_folder='main',dir_storage = 'Storage'):
    if sub_folder=='main':
        return os.path.join(dir_storage,str(job_id))
    if sub_folder == 'g':
        print('here2',dir_storage,job_id)
        return os.path.join(dir_storage,str(job_id),job_genomes_folder)
    if sub_folder == 'm':
        return os.path.join(dir_storage,str(job_id),job_metadata_folder)
    if sub_folder == 'ao':
        return os.path.join(dir_storage,str(job_id),job_assembly_folder)
    if sub_folder == 'go':
        return os.path.join(dir_storage,str(job_id),job_gene_pred_folder)
    if sub_folder == 'co':
        return os.path.join(dir_storage,str(job_id),job_compGenomics_folder)
    


def my_log(i):
    print(i)

def next_job(jobs_file):
    jobs = SVtoLIST(jobs_file,',')
    for job in jobs:
        if job[4] == 'email_not_sent':
            return job
        if job[3] == 'incomplete':
            return job
    return None

# add ctrl 
def update_job_file(jobs_file,job,col,update_to,update_to2=None):
    update = job.copy()
    my_log(f'JOB_FILE_UPDATE: the update line before updating{update}')
    if col == 'email':
        my_log(f'JOB_FILE_UPDATE: updating email val {job}')
        update[4] = update_to
    
    if col == 'pipeline_f':
        my_log('JOB_FILE_UPDATE: updating pipeline completed')
        update[3] = update_to
        update[4] = update_to2

    if col == 'pipeline_s':
        my_log('JOB_FILE_UPDATE: updating pipeline completed')
        update[3] = update_to
        update[4] = update_to2

    my_log(f'JOB_FILE_UPDATE: the update line from {update} to  {update_to}')
    jobs = JOBtoLIST(jobs_file,',')
    for i, j in enumerate(jobs):
        if job == j:
            jobs[i] = update
            my_log(f'JOB_FILE_UPDATE: the updates line in jobs[i] {jobs[i]}')
            break
    my_log(f'JOB_FILE_UPDATE: updated jobs file {jobs}')
    LISTtoJOB(jobs,',',jobs_file)

def file_control(_SVfile, flag):

    if os.path.isfile(_SVfile) == True:
        lock_file = _SVfile+'.lock'
        if flag == 'status':

            my_log(f'FILE_CONTROL: status of {lock_file}')
            input()
            if os.path.isfile(lock_file) == True:
                my_log(f'FILE_CONTROL: status of {lock_file} is locked')
                return 'locked'
            else:
                my_log(f'FILE_CONTROL: status of {lock_file} is locked')
                return 'unlocked'
        if flag == 'lock':
            my_log(f'FILE_CONTROL: trying to lock {lock_file}')
            my_log(f'FILE_CONTROL: ')
            open(lock_file, 'a').close()
        if flag == 'unlock':
            try:
                my_log(f'FILE_CONTROL: trying to unlock {lock_file} by deleting lock file')
                os.remove(lock_file)
            except:
                my_log(f'file control: tried to remove non existing lock file {lock_file}')
        time.sleep(1)


    else:
        my_log(f'file control: the file {_SVfile} does not seem to exist')
    


def send_link(to_email,subject,email_content,mode='send'):
    print(to_email,subject,email_content)

    if mode == 'test':
        # return None #activate when testing
        pass
        
    msg = EmailMessage()
    msg.set_content(email_content)


    msg['Subject'] = subject
    msg['From'] = "team3webserver@gmail.com"
    msg['To'] = to_email

    # Send the message via our own SMTP server.
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.login("team3webserver@gmail.com", "kkk8R+nz")
    server.send_message(msg)
    server.quit()