import os
import time

def process(file):
    time.sleep(5)
    return 'Done'

while True:
    try:
        file = 'Storage/'+str(min([int(i[:i.find('.')]) for i in os.listdir('Storage')]))+'.zip'
        process(file)
        os.system(f'rm {file}')
    except:
        continue
