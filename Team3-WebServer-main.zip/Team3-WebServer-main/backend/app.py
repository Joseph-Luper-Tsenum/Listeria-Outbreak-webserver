from flask import Flask,request,send_from_directory
import simplejson as json
from flask_cors import CORS, cross_origin
from werkzeug.utils import secure_filename
import os
# from send_dat_email_exclamation_mark import send_link
from subprocess import call
# import genome_assembly
import other_functions

app = Flask(__name__,static_folder='Storage')
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'
dirpath = 'Storage'
job_id_file = os.path.join(dirpath, 'jobs.csv')

USERS_SO_FAR = 0


# Get TSV File Routing
@app.route('/tsv/<folder>',methods = ['GET','POST'])
@cross_origin()
def get_tsv(folder):

        jobfolder = os.path.join(app.static_folder,folder,'metadata')

        for file in os.listdir(jobfolder):
                if file.endswith(".tsv"):
                        fn = file

        try:
                return send_from_directory(directory = jobfolder, path=fn, as_attachment=True)
        except FileNotFoundError:
                print("File not found")


# Get NEWICK File Routing
@app.route('/nw/<folder>',methods = ['GET','POST'])
@cross_origin()
def get_nw(folder):

        jobfolder = os.path.join(app.static_folder,folder,'comparative_genomics')

        for file in os.listdir(jobfolder):
                if file.endswith(".newick"):
                        fn = file

        try:
                return send_from_directory(directory = jobfolder, path=fn, as_attachment=True)
        except FileNotFoundError:
                print("File not found")


# Get Zip File Routing
@app.route('/zip/<folder>',methods = ['GET','POST'])
@cross_origin()
def get_zip(folder):

        jobfolder = os.path.join(app.static_folder,folder)

        for file in os.listdir(jobfolder):
                if file.endswith(".zip"):
                        fn = file

        try:
                return send_from_directory(directory = jobfolder, path=fn, as_attachment=True)
        except FileNotFoundError:
                print("File not found")



@app.route("/file", methods = ['GET','POST'])
@cross_origin()
def file():
        if request.method == 'POST':
                all_files = []

                # get the files and email from front end 
                genomes_files = request.files.getlist("Genome")
                metadata_files = request.files.getlist("Metadata")
                Email = request.form['Email']

                # create the jobid and folder 
                this_job_id = other_functions.create_job_id(
                        jobs_file = job_id_file,
                        task='full_pipeline',
                        dir_storage=dirpath,
                        username=Email)

                this_job_folder = other_functions.job_folder(this_job_id)
                job_genomes = other_functions.job_folder(this_job_id, sub_folder='g')
                job_metadata = other_functions.job_folder(this_job_id,sub_folder='m')

                # store genomes in genome folder

                for genome_file in genomes_files:
                        other_functions.my_log(f'genome file {genome_file.filename} of job id {this_job_id} being added to {job_genomes}')
                        file_path = os.path.join(job_genomes, secure_filename(genome_file.filename))
                        print('here ',job_genomes, file_path)
                        genome_file.save(file_path)
                        all_files.append(file_path)

                for metadata_file in metadata_files:
                        # print('file info: ',metagene_file,metagene_file.filename)
                        other_functions.my_log(f'metadata file {metadata_file.filename} of job id {this_job_id} being added to {job_metadata}')
                        file_path = os.path.join(job_metadata, secure_filename(metadata_file.filename))
                        metadata_file.save(file_path)
                        all_files.append(file_path)

                # other_functions.my_log('sending email to user')
                # other_functions.send_link(
                #         Email,
                #         'job submitted for computational genomics',
                #         f'Your job {this_job_id} has been submitted and you will get the link for results by email once it is complete'
                #         )

                # other_functions.my_log('done sending email')
                # print(genomes_files, metagene_files, Email)

        
        return("1")


@app.route("/fu", methods = ['GET', 'POST'])
@cross_origin()
def fu():
        if request.method == 'POST':
                f = request.files.getlist("file[]")
                all_files = []
                this_job_id = other_functions.create_job_id(
                        jobs_file = job_id_file,
                        task='genome_assembly',
                        dir_storage=dirpath,
                        username='abangaru3@gatech.edu')
                this_job_folder = other_functions.job_folder(this_job_id)
                for file in f:
                        print('file info: ',file,file.filename)
                        file_path = os.path.join(this_job_folder, secure_filename(file.filename))
                        file.save(file_path)
                        all_files.append(file_path)

                 # Call assembly pipeline. Assumes Team3-GenomeAssembly github has been cloned adjacent to Team3-WebServer.
                assembly_out = this_job_folder+'/assembly_out'
                call(['python', '../../Team3-GenomeAssembly/Pipeline.py', '-i', this_job_folder, '-o', assembly_out, '-q', '-a', 'spades']) # Includes quality control

                # Call gene prediction pipeline. Assumes Team3-GenePrediction github has been cloned adjacent to Team3-WebServer.
                gene_prediction_out = this_job_folder
                #call(['python', '../../Team3-GenePrediction/gp-pipe-c.py', '-i', assembly_out+'/spades/contigs', '-o', gene_prediction_out])
                call(['python', '../../Team3-GenePrediction/gp-pipe-nc.py', '-i', assembly_out + '/spades/contigs', '-o', gene_prediction_out])

                # Call comparative genomics pipeline. Assumes Team3-ComparativeGenomics github has been cloned adjacent to Team3-WebServer.
                #os.system("rm Storage/jobs.csv")
                #os.system("rm Storage/1/newfile.txt")
                compGenomics_out = this_job_folder
                #Requires conda environment named "webserver-env2.2"  with fastani and abricate installed. The command will activate the environment.
                call('conda run -n webserver-env2.2 python3 ../../Team3-ComparativeGenomics/Comparative_genomics_pipeline.py -i ' +assembly_out + '/spades/contigs -o ' +compGenomics_out+' -f -a', shell=True)

                return 'file uploaded successfully'


if __name__ == '__main__':
    app.run(debug=True)
