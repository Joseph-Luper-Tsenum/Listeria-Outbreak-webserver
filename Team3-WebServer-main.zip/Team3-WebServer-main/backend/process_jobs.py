from subprocess import call
import other_functions
import os
import time
dirpath = 'Storage'
job_id_file = os.path.join(dirpath, 'jobs.csv')

def team3_pipeline(job_id):

    main_job_folder = other_functions.job_folder(job_id)
    assembly_in = other_functions.job_folder(job_id,sub_folder='g')
    assembly_out = other_functions.job_folder(job_id,sub_folder='ao')
    gene_prediction_out = other_functions.job_folder(job_id,sub_folder='go')
    compGenomics_out = other_functions.job_folder(job_id,sub_folder='co')

    other_functions.my_log(f'running genome assembly')
     # Call assembly pipeline. Assumes Team3-GenomeAssembly github has been cloned adjacent to Team3-WebServer.
    # assembly_out = this_job_folder+'/assembly_out'
    call(['python', '../../Team3-GenomeAssembly/Pipeline.py', '-i', assembly_in, '-o', assembly_out, '-q', '-a', 'spades']) # Includes quality control

    other_functions.my_log(f'running gene pred')
    # Call gene prediction pipeline. Assumes Team3-GenePrediction github has been cloned adjacent to Team3-WebServer.
    # gene_prediction_out = this_job_folder
    #call(['python', '../../Team3-GenePrediction/gp-pipe-c.py', '-i', assembly_out+'/spades/contigs', '-o', gene_prediction_out])
    call(['python', '../../Team3-GenePrediction/gp-pipe-nc.py', '-i', assembly_out + '/spades/contigs', '-o', gene_prediction_out])

    other_functions.my_log(f'running comp genomics')
    # Call comparative genomics pipeline. Assumes Team3-ComparativeGenomics github has been cloned adjacent to Team3-WebServer.
    #os.system("rm Storage/jobs.csv")
    #os.system("rm Storage/1/newfile.txt")
    # compGenomics_out = this_job_folder
    #Requires conda environment named "webserver-env2.2"  with fastani and abricate installed. The command will activate the environment.
    call('conda run -n webserver-env2.2 python3 ../../Team3-ComparativeGenomics/Comparative_genomics_pipeline.py -i ' +assembly_out + '/spades/contigs -o ' +compGenomics_out+' -f -a', shell=True)

    other_functions.my_log(f'running zip')
    call(f'pwd')
    call(f'zip -r {main_job_folder}/{job_id}.zip {main_job_folder}/*', shell=True)

def each_iter(job):
    if job[4] == 'email_not_sent':
        other_functions.my_log(f'JOB: sending first email to {job}')

        other_functions.send_link(
            job[1],
            'job submitted for comparative genomics',
            f'Your job {job[0]} has been submitted and you will get the link for results by email once it is complete',
            mode='test',
            )

        other_functions.my_log(f'JOB: done sending first email to {job}')

        other_functions.update_job_file(job_id_file,job, 'email','first_email_sent')
    elif job[3] == 'incomplete':
        other_functions.my_log(f'starting pipeline for {job}')

        team3_pipeline(job[0])

        other_functions.my_log(f'pipeline completed for {job}')

        # other_functions.update_job_file(job_id_file,job, 'pipeline','complete')


        other_functions.my_log(f'sending final email to {job}')
        other_functions.send_link(
            job[1],
            'job completed for comparative genomics',
            f'Your job {job[0]} has been compleated and you can view your results at http://groupc.bioappgenome22.biosci.gatech.edu/results/{job[0]}',
            mode = 'test',
            )
        other_functions.my_log(f'done sending final email to {job}')


        other_functions.update_job_file(job_id_file,job, 'pipeline_s', 'complete', 'final_email_sent')



while True:
    starttime = time.time()
    job = other_functions.next_job(job_id_file)
    

    if job == None:
        # break
        # other_functions.my_log('nothing to run')
        pass
    else:
        print('job recieved',job)
        each_iter(job)
    # if time.time() < starttime + 60:
    #     time.sleep(60)
        

    # break

