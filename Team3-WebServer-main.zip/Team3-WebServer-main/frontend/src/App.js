// import logo from './logo.svg';
// import './App.css';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import FU from './components/Home/FU'
import TU from './components/Home/TU'
import Home from './components/Home/Home'
import Organizer from './components/Pipeline/organizer'
import IP from './components/Pipeline/Input'
import Results from './components/Pipeline/Results'
import Heatmap from './components/Pipeline/Heatmap';
import Phylo from './components/Pipeline/Phylo';
// import Worldmap from './components/Home/6242.js'

function App() {
  return (
    <Router>
    <div className="App">
      <header className="App-header">
        <Routes>
        <Route exact path="/" element={<Home/>}/>
        <Route path="/input" element={<IP/>}/>
        <Route path="/results/:id" element={<Results/>}/>
        <Route path="/heatmap" element={<Heatmap/>}/>
        <Route path="/phylo" element={<Phylo/>}/>
        {/* <Route path="/worldmap" element={<Worldmap/>}/> */}
        <Route path="/fu" element={<FU/>}/>
        <Route path="/tu" element={<TU/>}/>
        </Routes>
      </header>
    </div>
    </Router>

  );
}

export default App;
