import React,{useState} from 'react'
import Navbar from '../Layout/Navbar'
import TextField from '@mui/material/TextField'
import Button from '@mui/material/Button'
// import { useLocation } from 'react-router-dom';
import axios from 'axios';
// import {Link} from 'react-router-dom';


export default function TU() {

  const [text,setText] = useState('');

  function handleSubmit(e) { 
    e.preventDefault()

    var myParams ={
        'Text':text
    }
    console.log(myParams)
  

    if (myParams !== "") {
        axios.post('http://localhost:5000/tu', myParams)
            .then(function(response){
                console.log(response);
       //Perform action based on response
        })
        .catch(function(error){
            console.log(error);
       //Perform action based on error
        });
    
        };
  }

  return (
    <div>
        <Navbar/>

        <div  align="center" style={{ marginTop: '16%'}}>
  
                <form onSubmit={handleSubmit}>
                <TextField id="filled-basic" label="Enter Text" type="text" required
                value={text}
                onChange={e => setText(e.target.value)} />
            
                <div align = "center">
                  <br></br>
               <Button variant = 'contained'
                type='submit'><b>Submit</b></Button> 
                </div>
                </form>
                
      </div>

    </div>

  )
}
