import React from "react";
import { Input } from '@mui/material';
import Navbar from '../Layout/Navbar'



export default function FU() {
    
    return (
      <div>
      <Navbar/>

      <div  align="center" style={{ marginTop: '16%'}}>
      
      <form action="http://localhost:5000/fu" method="POST" enctype = "multipart/form-data" 
      onSubmit={(e) => { alert('Submitted form!'); } }>
      
        <Input type = "file" name = "file[]"  inputProps={{ multiple: true }} />
        <br></br>
         <Input variant = "contained" type = "submit" />
        </form>

      </div >
      </div>
    );
  }
