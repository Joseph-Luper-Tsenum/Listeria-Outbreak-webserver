import React from 'react'
import Navbar from '../Layout/Navbar'
import Button from '@mui/material/Button';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div>
        <Navbar/>
        
        <div  align="center" style={{ marginTop: '15%'}}>
        <h2>Analysis of <i>Listeria monocytogenes</i> breakouts via webserver</h2>
        <br></br> <br></br> <br></br>

          <Link to = "/input"><Button variant="contained" size="large" style={{ background: '#2E3B55'}}>Start</Button></Link>
            
          </div>

    </div>
  )
}
