import React, { useEffect, useState} from 'react'
import Organizer from "./organizer";
import { useLocation } from 'react-router-dom';
import Navbar from '../Layout/Navbar';
import { Button } from '@mui/material';
import { Link } from 'react-router-dom';

export default function Results() {


  return (
    <div>
      <Navbar />
      <div align="center" style={{ marginTop: '15%'}}>
      <Link to="/phylo" state={{jobid : useLocation().pathname.substring(9)}}>
          <Button  variant="contained" size="large" style={{ background: '#2E3B55'}}>Phylogeny Tree</Button>
          </Link>
      
        <br></br> <br></br><br></br>
        <Link to="/heatmap" state={{jobid : useLocation().pathname.substring(9)}}>
         <Button  variant="contained" size="large" style={{ background: '#2E3B55'}}>US Bubble Map</Button>
         </Link>

         <br></br> <br></br><br></br>
        <a href= {`/b/zip/${useLocation().pathname.substring(9)}`} >
         <Button  variant="contained" size="large" style={{ background: '#2E3B55'}}>Download Results Zipped</Button>
         </a>


       </div>
    </div>
  )
}

