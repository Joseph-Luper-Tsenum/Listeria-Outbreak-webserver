import React from 'react'
import { Grid, Paper, Typography } from '@mui/material';
import * as d3 from 'd3';
import{useEffect,useState} from 'react';
import { useLocation } from 'react-router-dom';
import Navbar from '../Layout/Navbar'
import { Button } from '@mui/material';
import { Link } from 'react-router-dom';

export default function Heatmap() {

    var jobid = useLocation().state.jobid
    // console.log(jobid)


    function USmap(){
        useEffect(() => {
            //Width and height of map
        var width = 800;
        var height = 500;
    
        // D3 Projection
        var projection = d3.geoAlbersUsa()
                        .translate([width/2, height/2])    // translate to center of screen
                        .scale([1000]);          // scale things down so see entire US
                
        // Define path generator
        var path = d3.geoPath()               // path generator that will convert GeoJSON to SVG paths
                    .projection(projection);  // tell path generator to use albersUsa projection
    
                
        // Define linear scale for output
        var color = d3.scaleLinear()
        .range(["#f1eef6", "#bdc9e1"])
    
        // var legendText = ["Cities Lived", "States Lived", "States Visited", "Nada"];
    
        //Create SVG element and append map to the SVG
        var svg = d3.select("#my_dataviz")
                    .append("svg")
                    .attr("width", width)
                    .attr("height", height);
                
        // Append Div for tooltip to SVG
        var div = d3.select("#my_dataviz")
                    .append("div")   
                    .attr("class", "tooltip")               
                    .style("opacity", 0);
        
            
        // Load the metadata
        d3.tsv(`/b/tsv/${jobid}`, function(data){
            // create a dictionary of states and occurance
            var states = {};
            for (var info in data){
                var state = data[info].Location;
                // if the state is not in the dictionary, add it
                if (!states[state]){
                    states[state] = 1;
                }
                // if the state is in the dictionary, add the occurance
                else{
                    states[state] += 1;
                }
            }
            
        d3.json("us-states.json", function(json) {
            // conver the dicitionary to appropriate format with the key as the state name and the value as the occurance
            //console.log(states)
         
            var states_list = Object.entries(states).map(function(d) {
                return {
                    state: d[0],
                    value: d[1]
                };
            });
            // loop through each state data value in the states dictionary
            for (const [key, value] of Object.entries(states)) {
                // loop through each state in the json
                for (var i = 0; i < json.features.length; i++) {
                    // if the state name matches the state name in the dictionary
                    if (json.features[i].properties.name == key) {
                        // assign the value to the state's property called "value"
                        //store the state location and value in an object
                        json.features[i].properties.value = value;
                        break;
                    }
                }
            }
            //console.log(states_list)
            // Bind the data to the SVG and create one path per GeoJSON feature
            svg.selectAll("path")
            .data(json.features)
            .enter()
            .append("path")
            .attr("d", path)
            .style("stroke", "#fff")
            .style("stroke-width", "1")
            .style("fill", "#b8b8b8")
            .style("opacity", 0.8)
    
            // adding tooltip
            var tooltip = d3.select("#my_dataviz")
            .append("div")
            .attr("id", "tooltip")
            .style("position", "absolute")
            .style("visibility", "hidden")
            .style("background-color", "white")
            .style("border", "solid")
            .style("border-width", "1px")
            .style("border-radius", "5px")
            .style("padding", "10px")
    
    
        //add circles to the map
        svg.selectAll("circle")
            .data(states_list)
            .enter()
            .append("circle")
            .attr("transform", function(d) {
                for (var i = 0; i < json.features.length; i++) {
                    var p = json.features[i];
                    if (p.properties.name == d.state) {
                        var t = path.centroid(p);
                        return " translate("+ t +")";
                    }
                }   
            })
            .attr("r", function(d) {
                return d.value * 1.5;
            })
            .style("fill", function(d) {
                return color(d.value);
            })
            .attr("stroke-width", 4)
            .attr("fill-opacity", 0.8)
            .on("mouseover", function() {
                return tooltip.style("visibility", "visible");
            })
            .on("mousemove", function(d) {
                ////console.log(data)
                // loop through the data and ge the info of the state that matches the state name
                var info_list = []
                for (var i = 0; i < data.length; i++) {
                    if (data[i].Location == d.state) {
                        info_list.push(data[i])
                    }
                }
                //console.log(info_list)
                // loop through the info list and add the info to the tooltip
                var info = ""
                for (var i = 0; i < info_list.length; i++) {
                    info += "<p>" + info_list[i].ID + ": " + info_list[i].Food1 + " " + info_list[i].Food2 + " "  + info_list[i].Food3 + " " + info_list[i].Food4 +"</p>"
                }
                return tooltip.html(info).style("top", (d3.event.pageY - 10) + "px").style("left", (d3.event.pageX + 10) + "px");
            })
            .on("mouseleave", function(d) {
                return tooltip.style("visibility", "hidden");
            })
    
    
            
    
    
    
    
            
    
    })
    
        })
    
    
        })
        return(
            
            <div> 
                
                <div id = "my_dataviz" ></div>
            </div>
        );
    }


  return (

    <div>
    <Navbar/>
    <div align="center" style={{marginTop:"7%"}}> <Grid item lg={5} >
            <USmap ></USmap >  
            </Grid>

            <br></br>
                  
            <div>
                   
                    You can hover on the bubble to discover the food source and isolates of outbreak 
            
            </div>
            <br></br><br></br>
            <Link to={'/results/'+jobid} >
         <Button  variant="contained" size="large" style={{ background: '#2E3B55'}}>Back</Button>
         </Link>
    </div>
    </div>
  )
}
