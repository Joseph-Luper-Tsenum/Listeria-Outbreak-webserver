import React from 'react'
import { Grid, Paper, Typography } from '@mui/material';
import * as d3 from 'd3';
import{useEffect,useState} from 'react';
import {Phylogician, Tree} from 'phylogician-ts';
import { useLocation } from 'react-router-dom';
import Navbar from '../Layout/Navbar'
import { Button } from '@mui/material';
import { Link } from 'react-router-dom';

export default function Phylo() {

    var jobid = useLocation().state.jobid

    function Phylogentics_treee(){
        useEffect(() => {
            d3.text(`/b/nw/${jobid}`, newick => {
                //console.log(newick)
                const phyloTree = new Phylogician(undefined, 'debug')
                const svgParams = {
                  width: 800,
                  height: 800
                }
                if (phyloTree.tree.nodes.length === 0) {
                  phyloTree
                    .data(newick)
                    .setSvgParameters(svgParams)
                    .setLayout('Vertical')
                    .setFontSizeAllLabels(10)
                    .tree.nodes.forEach((node) => {
                      node.setNodeColor('none')
                      // node.name.match(/(^GB|^RS|^GC|^UB|^unti)/) && node.setShowLabel(false)
                      
                    })
                  phyloTree.draw("#my_dataviz")
                }
    
            })
        })
        
    
    return(
        <div> 
            
            <div id = "my_dataviz" ></div>
        </div>
    );
    }


  return (
    <div>
        <Navbar/>
        <div align="center" style={{marginTop:"7%"}}>
                   

         The Phylogeny of the isolates <br></br> <br></br>
           
          
               
            <Grid item lg={12} >
           
           <Phylogentics_treee></Phylogentics_treee>
           
           </Grid>

           <br></br><br></br>
            <Link to={'/results/'+jobid} >
         <Button  variant="contained" size="large" style={{ background: '#2E3B55'}}>Back</Button>
         </Link>
           </div>

    </div>
  )
}
