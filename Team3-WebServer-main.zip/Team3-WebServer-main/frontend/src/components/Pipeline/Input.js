import React from 'react';
import Navbar from '../Layout/Navbar';
import { makeStyles } from '@material-ui/core';
import axios from 'axios';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import FileUpload from 'react-material-file-upload';
import Grid from '@mui/material/Grid';
import {Link} from 'react-router-dom'
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';


const style = {
  position: 'absolute',
  top: '30%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: '30%',
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
const useStyles = makeStyles(theme => ({
  root: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: theme.spacing(2),

    '& .MuiTextField-root': {
      margin: theme.spacing(1),
      width: '300px',
    },
    '& .MuiButtonBase-root': {
      margin: theme.spacing(2),
    },
  },
}));



export default function GA() {
  const classes = useStyles();

  const [files, setFiles] = React.useState([]);
  const [files2, setFiles2] = React.useState([]);
  const [text,setText] = React.useState('');
  const [done,setDone] = React.useState(null);
  const [open, setOpen] = React.useState(false);
  const handleClose = () => setOpen(false)

  function handleSubmit(e) { 
    e.preventDefault()

      console.log(files,files2)
      
      const data = new FormData();
      for (let i = 0; i < files.length; i++) {
        data.append("Genome", files[i]);
      }

      for (let i = 0; i < files2.length; i++) {
        data.append("Metadata", files2[i]);
      }

      data.append("Email",text)

          axios.post('/b/file', data,{})
          .then(function(response){
                  console.log(response);
                  setDone(response.data)
      

              //Perform action based on response
                })
                .catch(function(error){
                    console.log(error);
              //Perform action based on error
                })
          
  };

  ((done === 1) && (open === false) ) ? setOpen(true) : console.log("Close")

  return (
    <div>
        <Navbar/>
        <div  align="center" style={{ marginTop: '3%'}}>
        <br></br><br></br>
        <form className={classes.root} onSubmit={handleSubmit}>
        <Grid container spacing={3}>
          <Grid item xs>
          <div  style={{ marginLeft: '10%', marginRight: '10%'}}>
          
          <h2>Genome Assembly</h2>
          <h3>Tool : SPAdes</h3>
          <FileUpload title={<div  style={{ fontSize: "150%"}}>Upload / Drag 'n' Drop Isolate files here in <b>.fq.gz</b> format</div>} value={files} onChange={setFiles} required />

          </div>
          </Grid>
         
          <Grid item xs>
          <div  style={{ marginLeft: '10%', marginRight: '10%'}}>
          
          <h2>Comparative Genomics</h2>
          <h3>Metadata Files (Optional)</h3>
          <FileUpload title={<div  style={{ fontSize: "150%"}}>Upload / Drag 'n' Drop Metadata files here in <b>.csv</b> format</div>} value={files2} onChange={setFiles2} />
          </div>

          </Grid>
        </Grid>
        
        <br></br><br></br><br></br>

        <TextField id="filled-basic" label="Enter Email" type="email" required
                value={text}
                onChange={e => setText(e.target.value)} />
        <br></br>
            
        <Button variant = 'contained' type='submit' style={{ background: '#2E3B55'}} size="large">Submit</Button> 
        </form>


        

        </div>


        <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <h2 align="center">
            Submission Complete !!!
          </h2>
          <div align="center">
            Check Your Email (and Spam Folder) for Results
          </div>
          <br></br><br></br>
          <div align="center">
          <Link to='/'><Button style={{ background: '#2E3B55', color:'white'}} size="large">Close</Button></Link>
          </div>
        </Box>
      </Modal>

    </div>
  )
}
