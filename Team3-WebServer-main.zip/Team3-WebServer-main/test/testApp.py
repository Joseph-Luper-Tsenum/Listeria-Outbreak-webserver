from flask import Flask
from markupsafe import escape # Needed if user-provided values will be rendered in the output.
from flask import render_template # Required to render html.

# Initialize flask object.
app = Flask(__name__) # Need "assets" folder provided by bootstrap to "static", Flask's default. Also change any html doc to reference "static" instead of "assets"

# Main webpage accessed via IP (or URL if there's one associated with it)
@app.route("/")
def index():
    return ("Colin's first Flask script.")

# Test page; access by adding "/foobar" after IP (or URL)
@app.route("/results")
def blah():
    return("This is a test results page.")

# Webpage using user-provided value (their name).
@app.route("/<name>")
def hello(name):
    return(f"Hello, {escape(name)}!") # Escape needed for user-provided values rendered in the output to prevent injection attacks. What's an injection attack?

# Webpage rendering a bootstrap-created html.
# Assumes html is in same directory as flask script.
@app.route("/personalwebpage")
def personal(name=None):
    return(render_template("ColinsTestWebsite.html")) # render_templates() looks for "templates" folder in the same directory as the script by default.

# Run the flask app.
app.run(host='0.0.0.0', port=80) # Requires setting up port forwarding on your router.
#app.run(host='127.0.0.1', port=80) # Use this if you just want to access the site on your local network
